# 23CSE202 — Contact Management System (Group D9)
Frontend: `index.html`, `styles.css`, `app.js`, `api.js` · Backend: `backend/` (Node/Express + PostgreSQL). See `backend/README.md`.
