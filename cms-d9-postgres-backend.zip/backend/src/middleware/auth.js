const jwt = require('jsonwebtoken');
const { pool } = require('../db');
const { HttpError, asyncHandler } = require('../httpError');

const JWT_SECRET = process.env.JWT_SECRET || 'dev-only-secret-change-me';
if (!process.env.JWT_SECRET) console.warn('[warn] JWT_SECRET not set — using an insecure development default.');

const signToken = (user) =>
  jwt.sign({ sub: user.user_id }, JWT_SECRET, { expiresIn: process.env.JWT_EXPIRES_IN || '8h' });

/** Verifies the Bearer token and re-reads the user's CURRENT role from the DB,
 *  so an admin changing a role (or deleting a user) takes effect immediately. */
const requireAuth = asyncHandler(async (req, _res, next) => {
  const header = req.headers.authorization || '';
  const token = header.startsWith('Bearer ') ? header.slice(7) : null;
  if (!token) throw new HttpError(401, 'UNAUTHENTICATED', 'Please sign in.');
  let payload;
  try { payload = jwt.verify(token, JWT_SECRET); }
  catch { throw new HttpError(401, 'UNAUTHENTICATED', 'Session expired. Please sign in again.'); }
  const { rows } = await pool.query('SELECT user_id, username, role FROM users WHERE user_id = $1', [payload.sub]);
  if (!rows[0]) throw new HttpError(401, 'UNAUTHENTICATED', 'This account no longer exists.');
  req.user = { id: rows[0].user_id, username: rows[0].username, role: rows[0].role };
  next();
});

const requireRole = (...roles) => (req, _res, next) => {
  if (!roles.includes(req.user.role)) {
    return next(new HttpError(403, 'FORBIDDEN', 'Your role does not allow this action.'));
  }
  next();
};

const canEdit = requireRole('Administrator', 'Editor');
const adminOnly = requireRole('Administrator');

module.exports = { signToken, requireAuth, requireRole, canEdit, adminOnly };
